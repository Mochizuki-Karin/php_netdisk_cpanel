<?php
require_once 'config/database.php';

class Auth {
    private $db;
    
    public function __construct() {
        $this->db = new Database();
    }
    
    // 用户注册
    public function register($username, $password) {
        // 检查用户名是否已存在
        $existing = $this->db->fetchOne(
            "SELECT id FROM users WHERE username = ?", 
            [$username]
        );
        
        if ($existing) {
            return ['success' => false, 'message' => '用户名已存在'];
        }
        
        // 创建新用户
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        $this->db->query(
            "INSERT INTO users (username, password_hash) VALUES (?, ?)",
            [$username, $passwordHash]
        );
        
        return ['success' => true, 'message' => '注册成功'];
    }
    
    // 用户登录
    public function login($username, $password) {
        $user = $this->db->fetchOne(
            "SELECT id, username, password_hash FROM users WHERE username = ?",
            [$username]
        );
        
        if ($user && password_verify($password, $user['password_hash'])) {
            session_start();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            return ['success' => true, 'message' => '登录成功'];
        }
        
        return ['success' => false, 'message' => '用户名或密码错误'];
    }
    
    // 检查是否已登录
    public function isLoggedIn() {
        session_start();
        return isset($_SESSION['user_id']);
    }
    
    // 获取当前用户ID
    public function getCurrentUserId() {
        session_start();
        return $_SESSION['user_id'] ?? null;
    }
    
    // 获取当前用户名
    public function getCurrentUsername() {
        session_start();
        return $_SESSION['username'] ?? null;
    }
    
    // 用户登出
    public function logout() {
        session_start();
        session_destroy();
        return ['success' => true, 'message' => '已退出登录'];
    }
    
    // 要求登录的中间件
    public function requireLogin() {
        if (!$this->isLoggedIn()) {
            header('Location: login.php');
            exit;
        }
    }
}
?>

