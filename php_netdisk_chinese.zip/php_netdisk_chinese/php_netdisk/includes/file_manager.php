<?php
require_once 'config/database.php';

class FileManager {
    private $db;
    private $uploadDir;
    
    public function __construct() {
        $this->db = new Database();
        $this->uploadDir = __DIR__ . '/../uploads/';
        
        // 确保上传目录存在
        if (!is_dir($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
    }
    
    // 获取用户的所有文件
    public function getUserFiles($userId) {
        return $this->db->fetchAll(
            "SELECT f.*, s.share_token FROM files f 
             LEFT JOIN shares s ON f.id = s.file_id 
             WHERE f.user_id = ? 
             ORDER BY f.created_at DESC",
            [$userId]
        );
    }
    
    // 上传文件
    public function uploadFile($userId, $file) {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'message' => '文件上传失败'];
        }
        
        $filename = $this->sanitizeFilename($file['name']);
        $filesize = $file['size'];
        $mimeType = $file['type'];
        
        // 生成唯一的文件名
        $uniqueFilename = uniqid() . '_' . $filename;
        $filePath = $this->uploadDir . $uniqueFilename;
        
        if (move_uploaded_file($file['tmp_name'], $filePath)) {
            // 保存文件信息到数据库
            $this->db->query(
                "INSERT INTO files (user_id, filename, filesize, file_path, mime_type) VALUES (?, ?, ?, ?, ?)",
                [$userId, $filename, $filesize, $uniqueFilename, $mimeType]
            );
            
            return ['success' => true, 'message' => '文件上传成功'];
        }
        
        return ['success' => false, 'message' => '文件保存失败'];
    }
    
    // 本地文件导入
    public function importLocalFile($userId, $localPath, $displayName = null) {
        if (!file_exists($localPath)) {
            return ['success' => false, 'message' => '本地文件不存在'];
        }
        
        $filename = $displayName ?: basename($localPath);
        $filename = $this->sanitizeFilename($filename);
        $filesize = filesize($localPath);
        $mimeType = mime_content_type($localPath);
        
        // 生成唯一的文件名
        $uniqueFilename = uniqid() . '_' . $filename;
        $targetPath = $this->uploadDir . $uniqueFilename;
        
        if (copy($localPath, $targetPath)) {
            // 保存文件信息到数据库
            $this->db->query(
                "INSERT INTO files (user_id, filename, filesize, file_path, mime_type) VALUES (?, ?, ?, ?, ?)",
                [$userId, $filename, $filesize, $uniqueFilename, $mimeType]
            );
            
            return ['success' => true, 'message' => '本地文件导入成功'];
        }
        
        return ['success' => false, 'message' => '文件复制失败'];
    }
    
    // 删除文件
    public function deleteFile($userId, $fileId) {
        $file = $this->db->fetchOne(
            "SELECT * FROM files WHERE id = ? AND user_id = ?",
            [$fileId, $userId]
        );
        
        if (!$file) {
            return ['success' => false, 'message' => '文件不存在或无权限'];
        }
        
        // 删除物理文件
        $filePath = $this->uploadDir . $file['file_path'];
        if (file_exists($filePath)) {
            unlink($filePath);
        }
        
        // 删除数据库记录
        $this->db->query("DELETE FROM files WHERE id = ?", [$fileId]);
        
        return ['success' => true, 'message' => '文件删除成功'];
    }
    
    // 重命名文件
    public function renameFile($userId, $fileId, $newName) {
        $newName = $this->sanitizeFilename($newName);
        
        $result = $this->db->query(
            "UPDATE files SET filename = ? WHERE id = ? AND user_id = ?",
            [$newName, $fileId, $userId]
        );
        
        if ($result->rowCount() > 0) {
            return ['success' => true, 'message' => '文件重命名成功'];
        }
        
        return ['success' => false, 'message' => '文件不存在或无权限'];
    }
    
    // 获取文件信息
    public function getFileInfo($fileId, $userId = null) {
        $sql = "SELECT * FROM files WHERE id = ?";
        $params = [$fileId];
        
        if ($userId !== null) {
            $sql .= " AND user_id = ?";
            $params[] = $userId;
        }
        
        return $this->db->fetchOne($sql, $params);
    }
    
    // 下载文件
    public function downloadFile($fileId, $userId = null) {
        $file = $this->getFileInfo($fileId, $userId);
        
        if (!$file) {
            return false;
        }
        
        $filePath = $this->uploadDir . $file['file_path'];
        
        if (!file_exists($filePath)) {
            return false;
        }
        
        // 设置下载头
        header('Content-Type: ' . $file['mime_type']);
        header('Content-Disposition: attachment; filename="' . $file['filename'] . '"');
        header('Content-Length: ' . $file['filesize']);
        
        readfile($filePath);
        return true;
    }
    
    // 清理文件名
    private function sanitizeFilename($filename) {
        // 移除危险字符
        $filename = preg_replace('/[^a-zA-Z0-9._\-\u4e00-\u9fa5]/u', '_', $filename);
        return $filename;
    }
    
    // 格式化文件大小
    public function formatFileSize($bytes) {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        
        $bytes /= (1 << (10 * $pow));
        
        return round($bytes, 2) . ' ' . $units[$pow];
    }
}
?>

