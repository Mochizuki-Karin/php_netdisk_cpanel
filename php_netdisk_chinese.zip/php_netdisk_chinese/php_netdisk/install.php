<?php
// 安装脚本 - 仅在首次安装时使用
// 安装完成后请删除此文件

$error = '';
$success = '';
$step = $_GET['step'] ?? 1;

// 检查是否已安装
if (file_exists('config/installed.lock')) {
    die('系统已安装，如需重新安装请删除 config/installed.lock 文件');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step == 1) {
        // 数据库配置
        $dbHost = $_POST['db_host'] ?? 'localhost';
        $dbName = $_POST['db_name'] ?? '';
        $dbUser = $_POST['db_user'] ?? '';
        $dbPass = $_POST['db_pass'] ?? '';
        
        if ($dbName && $dbUser) {
            try {
                // 测试数据库连接
                $pdo = new PDO("mysql:host=$dbHost;charset=utf8mb4", $dbUser, $dbPass);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                // 创建数据库
                $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                $pdo->exec("USE `$dbName`");
                
                // 创建表
                $sql = file_get_contents('database_schema.sql');
                $pdo->exec($sql);
                
                // 更新配置文件
                $configContent = file_get_contents('config/database.php');
                $configContent = str_replace('your_username', $dbUser, $configContent);
                $configContent = str_replace('your_password', $dbPass, $configContent);
                $configContent = str_replace('netdisk_db', $dbName, $configContent);
                $configContent = str_replace('localhost', $dbHost, $configContent);
                file_put_contents('config/database.php', $configContent);
                
                $success = '数据库配置成功！';
                $step = 2;
            } catch (PDOException $e) {
                $error = '数据库连接失败: ' . $e->getMessage();
            }
        } else {
            $error = '请填写所有必要信息';
        }
    } elseif ($step == 2) {
        // 创建管理员账户
        $username = $_POST['admin_username'] ?? '';
        $password = $_POST['admin_password'] ?? '';
        
        if ($username && $password && strlen($password) >= 6) {
            try {
                require_once 'includes/auth.php';
                $auth = new Auth();
                $result = $auth->register($username, $password);
                
                if ($result['success']) {
                    // 创建安装锁定文件
                    file_put_contents('config/installed.lock', date('Y-m-d H:i:s'));
                    
                    // 设置目录权限
                    chmod('uploads', 0755);
                    
                    $success = '安装完成！请删除 install.php 文件，然后登录系统。';
                    $step = 3;
                } else {
                    $error = $result['message'];
                }
            } catch (Exception $e) {
                $error = '创建管理员账户失败: ' . $e->getMessage();
            }
        } else {
            $error = '请填写用户名和密码（密码至少6位）';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP网盘 - 系统安装</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <div class="card" style="max-width: 600px; margin: 50px auto;">
            <div style="text-align: center; margin-bottom: 30px;">
                <h1 class="logo">📁 PHP网盘</h1>
                <p style="color: #666; margin-top: 10px;">系统安装向导</p>
            </div>
            
            <!-- 安装步骤指示器 -->
            <div style="display: flex; justify-content: center; margin-bottom: 30px;">
                <div style="display: flex; align-items: center;">
                    <div class="<?php echo $step >= 1 ? 'btn btn-primary' : 'btn btn-secondary'; ?>" style="border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;">1</div>
                    <div style="width: 50px; height: 2px; background: <?php echo $step >= 2 ? '#667eea' : '#ddd'; ?>;"></div>
                    <div class="<?php echo $step >= 2 ? 'btn btn-primary' : 'btn btn-secondary'; ?>" style="border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;">2</div>
                    <div style="width: 50px; height: 2px; background: <?php echo $step >= 3 ? '#667eea' : '#ddd'; ?>;"></div>
                    <div class="<?php echo $step >= 3 ? 'btn btn-primary' : 'btn btn-secondary'; ?>" style="border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;">3</div>
                </div>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            
            <?php if ($step == 1): ?>
                <h2>步骤 1: 数据库配置</h2>
                <form method="POST">
                    <div class="form-group">
                        <label for="db_host" class="form-label">数据库主机</label>
                        <input type="text" id="db_host" name="db_host" class="form-control" value="localhost" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_name" class="form-label">数据库名称</label>
                        <input type="text" id="db_name" name="db_name" class="form-control" placeholder="netdisk_db" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_user" class="form-label">数据库用户名</label>
                        <input type="text" id="db_user" name="db_user" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_pass" class="form-label">数据库密码</label>
                        <input type="password" id="db_pass" name="db_pass" class="form-control">
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%;">下一步</button>
                </form>
            <?php elseif ($step == 2): ?>
                <h2>步骤 2: 创建管理员账户</h2>
                <form method="POST">
                    <div class="form-group">
                        <label for="admin_username" class="form-label">管理员用户名</label>
                        <input type="text" id="admin_username" name="admin_username" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="admin_password" class="form-label">管理员密码</label>
                        <input type="password" id="admin_password" name="admin_password" class="form-control" required>
                        <small style="color: #666;">密码长度至少6位</small>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%;">完成安装</button>
                </form>
            <?php elseif ($step == 3): ?>
                <h2>安装完成！</h2>
                <div style="text-align: center; padding: 40px 0;">
                    <div style="font-size: 64px; color: #28a745; margin-bottom: 20px;">✅</div>
                    <p style="margin-bottom: 30px;">PHP网盘已成功安装！</p>
                    
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: left;">
                        <h4>重要提醒：</h4>
                        <ul style="margin: 10px 0; padding-left: 20px;">
                            <li>请立即删除 <code>install.php</code> 文件</li>
                            <li>确保 <code>uploads</code> 目录有写入权限</li>
                            <li>定期备份数据库和文件</li>
                            <li>建议修改默认的数据库配置</li>
                        </ul>
                    </div>
                    
                    <a href="login.php" class="btn btn-primary">立即登录</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

