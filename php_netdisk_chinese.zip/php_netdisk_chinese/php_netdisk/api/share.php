<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../includes/auth.php';
require_once '../includes/share_manager.php';

$auth = new Auth();

// 检查登录状态
if (!$auth->isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => '方法不允许']);
    exit;
}

// 获取JSON输入
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['file_id']) || !isset($input['action'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => '缺少必要参数']);
    exit;
}

$fileId = $input['file_id'];
$action = $input['action'];

if (!is_numeric($fileId)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => '无效的文件ID']);
    exit;
}

if (!in_array($action, ['create', 'delete', 'update'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => '无效的操作']);
    exit;
}

$shareManager = new ShareManager();
$userId = $auth->getCurrentUserId();

try {
    switch ($action) {
        case 'create':
            $expiresAt = $input['expires_at'] ?? null;
            $result = $shareManager->createShare($userId, $fileId, $expiresAt);
            break;
            
        case 'delete':
            $result = $shareManager->deleteShare($userId, $fileId);
            break;
            
        case 'update':
            $expiresAt = $input['expires_at'] ?? null;
            $result = $shareManager->updateShareExpiry($userId, $fileId, $expiresAt);
            break;
            
        default:
            $result = ['success' => false, 'message' => '未知操作'];
    }
    
    echo json_encode($result);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => '操作失败']);
}
?>

