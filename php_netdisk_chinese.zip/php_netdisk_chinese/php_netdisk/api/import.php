<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../includes/auth.php';
require_once '../includes/file_manager.php';

$auth = new Auth();

// 检查登录状态
if (!$auth->isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => '方法不允许']);
    exit;
}

$localPath = $_POST['local_path'] ?? '';
$displayName = $_POST['display_name'] ?? '';

if (empty($localPath)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => '请提供文件路径']);
    exit;
}

// 安全检查：防止路径遍历攻击
if (strpos($localPath, '..') !== false || strpos($localPath, '~') !== false) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => '无效的文件路径']);
    exit;
}

// 检查文件是否存在
if (!file_exists($localPath)) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => '指定的文件不存在']);
    exit;
}

// 检查是否为文件（不是目录）
if (!is_file($localPath)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => '指定的路径不是文件']);
    exit;
}

// 检查文件大小限制 (50MB)
$fileSize = filesize($localPath);
$maxFileSize = 50 * 1024 * 1024;
if ($fileSize > $maxFileSize) {
    echo json_encode(['success' => false, 'message' => '文件大小超过限制 (50MB)']);
    exit;
}

// 检查文件类型
$allowedTypes = [
    'image/jpeg', 'image/png', 'image/gif', 'image/webp',
    'video/mp4', 'video/avi', 'video/mov', 'video/wmv',
    'audio/mp3', 'audio/wav', 'audio/ogg',
    'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/zip', 'application/x-rar-compressed', 'application/x-tar',
    'text/plain', 'text/csv', 'text/html', 'text/css', 'text/javascript',
    'application/json', 'application/xml'
];

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $localPath);
finfo_close($finfo);

if (!in_array($mimeType, $allowedTypes)) {
    echo json_encode(['success' => false, 'message' => '不支持的文件类型']);
    exit;
}

$fileManager = new FileManager();
$userId = $auth->getCurrentUserId();

try {
    $result = $fileManager->importLocalFile($userId, $localPath, $displayName);
    echo json_encode($result);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => '导入文件时发生错误']);
}
?>

