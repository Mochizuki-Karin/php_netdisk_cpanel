<?php
require_once '../includes/auth.php';
require_once '../includes/file_manager.php';

$auth = new Auth();

// 检查登录状态
if (!$auth->isLoggedIn()) {
    http_response_code(401);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => '方法不允许']);
    exit;
}

$fileId = $_GET['id'] ?? '';

if (!$fileId || !is_numeric($fileId)) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => '无效的文件ID']);
    exit;
}

$fileManager = new FileManager();
$userId = $auth->getCurrentUserId();

// 尝试下载文件
if (!$fileManager->downloadFile($fileId, $userId)) {
    http_response_code(404);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => '文件不存在或无权限']);
    exit;
}
?>

