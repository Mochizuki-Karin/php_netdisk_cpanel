<?php
header('Content-Type: application/json');
require_once '../includes/auth.php';
require_once '../includes/file_manager.php';

$auth = new Auth();
$fileManager = new FileManager();

// 检查用户是否已登录
if (!$auth->isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

$userId = $auth->getCurrentUserId();
$search = $_GET['search'] ?? '';

// 获取文件列表
$files = $fileManager->getUserFiles($userId, $search);

// 格式化文件信息
$formattedFiles = [];
foreach ($files as $file) {
    $formattedFiles[] = [
        'id' => $file['id'],
        'original_name' => $file['original_name'],
        'file_size' => $file['file_size'],
        'file_type' => $file['file_type'],
        'created_at' => $file['created_at'],
        'formatted_size' => formatFileSize($file['file_size']),
        'icon' => getFileIcon($file['file_type'])
    ];
}

echo json_encode([
    'success' => true,
    'files' => $formattedFiles
]);

// 辅助函数
function formatFileSize($bytes) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    
    $bytes /= (1 << (10 * $pow));
    
    return round($bytes, 2) . ' ' . $units[$pow];
}

function getFileIcon($fileType) {
    $iconMap = [
        'image/jpeg' => '🖼️', 'image/png' => '🖼️', 'image/gif' => '🖼️', 'image/webp' => '🖼️',
        'video/mp4' => '🎥', 'video/avi' => '🎥', 'video/mov' => '🎥', 'video/wmv' => '🎥',
        'audio/mp3' => '🎵', 'audio/wav' => '🎵', 'audio/ogg' => '🎵',
        'application/pdf' => '📄', 'application/msword' => '📝', 'application/vnd.ms-excel' => '📊',
        'application/zip' => '📦', 'application/x-rar-compressed' => '📦',
        'text/plain' => '📄', 'text/csv' => '📊', 'text/html' => '🌐',
        'text/css' => '🎨', 'application/javascript' => '⚙️',
        'application/json' => '📋', 'application/xml' => '📋'
    ];
    
    return $iconMap[$fileType] ?? '📄';
}
?>

