<?php
header('Content-Type: application/json');
require_once '../includes/auth.php';
require_once '../includes/share_manager.php';

$auth = new Auth();
$shareManager = new ShareManager();

// 检查用户是否已登录
if (!$auth->isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

$userId = $auth->getCurrentUserId();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    // 创建分享链接
    $input = json_decode(file_get_contents('php://input'), true);
    $fileId = $input['file_id'] ?? '';
    $expiresAt = $input['expires_at'] ?? null;
    
    if (empty($fileId)) {
        echo json_encode(['success' => false, 'message' => '文件ID不能为空']);
        exit;
    }
    
    $result = $shareManager->createShare($fileId, $userId, $expiresAt);
    echo json_encode($result);
    
} elseif ($method === 'DELETE') {
    // 删除分享链接
    $input = json_decode(file_get_contents('php://input'), true);
    $shareId = $input['share_id'] ?? '';
    
    if (empty($shareId)) {
        echo json_encode(['success' => false, 'message' => '分享ID不能为空']);
        exit;
    }
    
    $result = $shareManager->deleteShare($shareId, $userId);
    echo json_encode($result);
    
} elseif ($method === 'GET') {
    // 获取用户分享列表
    $shares = $shareManager->getUserShares($userId);
    echo json_encode(['success' => true, 'shares' => $shares]);
    
} else {
    echo json_encode(['success' => false, 'message' => '不支持的请求方法']);
}
?>

