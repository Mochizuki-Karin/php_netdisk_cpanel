<?php
header('Content-Type: application/json');
require_once '../includes/auth.php';
require_once '../includes/file_manager.php';

$auth = new Auth();
$fileManager = new FileManager();

// 检查用户是否已登录
if (!$auth->isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

$userId = $auth->getCurrentUserId();

// 检查是否有文件上传
if (!isset($_FILES['file'])) {
    echo json_encode(['success' => false, 'message' => '没有选择文件']);
    exit;
}

$file = $_FILES['file'];

// 上传文件
$result = $fileManager->uploadFile($file, $userId);

echo json_encode($result);
?>

