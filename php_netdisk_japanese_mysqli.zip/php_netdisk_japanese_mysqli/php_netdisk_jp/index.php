<?php
require_once 'includes/auth.php';
require_once 'includes/file_manager.php';
require_once 'includes/share_manager.php';

$auth = new Auth();
$auth->requireLogin();

$fileManager = new FileManager();
$shareManager = new ShareManager();

$currentUser = $auth->getCurrentUsername();
$userId = $auth->getCurrentUserId();

// 获取统计信息
$userFiles = $fileManager->getUserFiles($userId);
$totalFiles = count($userFiles);
$totalSize = array_sum(array_column($userFiles, 'filesize'));
$shareCount = $shareManager->getShareStats($userId);
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHPクラウドストレージ - ファイル管理</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- 头部导航 -->
    <header class="header">
        <div class="header-content">
            <a href="index.php" class="logo">📁 PHPクラウドストレージ</a>
            <div class="user-info">
                <span>欢迎，<?php echo htmlspecialchars($currentUser); ?></span>
                <a href="logout.php" class="btn btn-secondary">🚪 ログアウト</a>
            </div>
        </div>
    </header>
    
    <div class="container">
        <!-- 统计信息 -->
        <div class="card">
            <h2 style="margin-bottom: 20px;">📊 存储概览</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 8px;">
                    <div style="font-size: 32px; color: #667eea; margin-bottom: 10px;">📄</div>
                    <div style="font-size: 24px; font-weight: bold; color: #333;"><?php echo $totalFiles; ?></div>
                    <div style="color: #666;">文件总数</div>
                </div>
                <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 8px;">
                    <div style="font-size: 32px; color: #28a745; margin-bottom: 10px;">💾</div>
                    <div style="font-size: 24px; font-weight: bold; color: #333;"><?php echo $fileManager->formatFileSize($totalSize); ?></div>
                    <div style="color: #666;">存储空间</div>
                </div>
                <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 8px;">
                    <div style="font-size: 32px; color: #ffc107; margin-bottom: 10px;">🔗</div>
                    <div style="font-size: 24px; font-weight: bold; color: #333;"><?php echo $shareCount; ?></div>
                    <div style="color: #666;">共有链接</div>
                </div>
            </div>
        </div>
        
        <!-- 文件アップロード区域 -->
        <div class="card">
            <h2 style="margin-bottom: 20px;">📤 アップロード文件</h2>
            <div class="upload-area" id="uploadArea">
                <div class="upload-icon">📁</div>
                <div class="upload-text">点击或拖拽文件到此处アップロード</div>
                <div class="upload-hint">支持多文件同时アップロード</div>
            </div>
            <input type="file" id="fileInput" multiple style="display: none;">
        </div>
        
        <!-- ファイル管理 -->
        <div class="card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>📂 我的文件</h2>
                <div style="display: flex; gap: 10px; align-items: center;">
                    <input type="text" id="searchInput" placeholder="検索文件..." class="form-control" style="width: 200px;">
                    <button class="btn btn-secondary" onclick="location.reload()">🔄 更新</button>
                </div>
            </div>
            
            <div class="file-list" id="fileList">
                <!-- 文件列表将通过JavaScript动态加载 -->
                <div style="text-align: center; padding: 40px; color: #666;">
                    <div style="font-size: 48px; margin-bottom: 20px;">⏳</div>
                    <div>正在加载文件列表...</div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 共有模态框 -->
    <div id="shareModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">共有文件</h3>
                <button class="modal-close">&times;</button>
            </div>
            <div id="shareContent">
                <!-- 共有内容将动态加载 -->
            </div>
        </div>
    </div>
    
    <!-- リネーム模态框 -->
    <div id="renameModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">リネーム文件</h3>
                <button class="modal-close">&times;</button>
            </div>
            <div class="form-group">
                <label for="newFileName" class="form-label">新文件名</label>
                <input type="text" id="newFileName" class="form-control" placeholder="输入新的文件名">
            </div>
            <div style="text-align: right; margin-top: 20px;">
                <button class="btn btn-secondary modal-close" style="margin-right: 10px;">キャンセル</button>
                <button class="btn btn-primary" onclick="netdisk.renameFile()">確認リネーム</button>
            </div>
        </div>
    </div>
    
    <!-- 本地文件导入模态框 -->
    <div id="importModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">导入本地文件</h3>
                <button class="modal-close">&times;</button>
            </div>
            <form id="importForm">
                <div class="form-group">
                    <label for="localPath" class="form-label">服务器文件路径</label>
                    <input type="text" id="localPath" name="local_path" class="form-control" 
                           placeholder="/path/to/your/file.txt" required>
                    <small style="color: #666; font-size: 12px;">输入服务器上文件的完整路径</small>
                </div>
                <div class="form-group">
                    <label for="displayName" class="form-label">显示名称（可选）</label>
                    <input type="text" id="displayName" name="display_name" class="form-control" 
                           placeholder="留空则使用原文件名">
                </div>
                <div style="text-align: right; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary modal-close" style="margin-right: 10px;">キャンセル</button>
                    <button type="submit" class="btn btn-primary">导入文件</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- 快捷操作按钮 -->
    <div style="position: fixed; bottom: 30px; right: 30px; z-index: 100;">
        <button class="btn btn-primary" onclick="document.getElementById('importModal').classList.add('show')" 
                style="border-radius: 50%; width: 60px; height: 60px; font-size: 24px; margin-bottom: 10px; display: block;">
            📥
        </button>
        <div style="font-size: 12px; text-align: center; color: white; text-shadow: 1px 1px 2px rgba(0,0,0,0.5);">
            导入本地文件
        </div>
    </div>
    
    <script src="assets/js/main.js"></script>
    <script>
        // 处理本地文件导入
        document.getElementById('importForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            try {
                const response = await fetch('api/import.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    netdisk.showAlert('文件导入成功', 'success');
                    netdisk.closeModal();
                    netdisk.loadFiles();
                    this.reset();
                } else {
                    netdisk.showAlert(result.message || '导入失败', 'error');
                }
            } catch (error) {
                netdisk.showAlert('导入过程中发生错误', 'error');
                console.error('Import error:', error);
            }
        });
    </script>
</body>
</html>

