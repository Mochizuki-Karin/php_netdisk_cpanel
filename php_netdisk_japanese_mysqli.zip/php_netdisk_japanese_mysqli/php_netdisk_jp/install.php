<?php
// 安装脚本 - 仅在首次安装时使用
// 安装完成后请削除此文件

$error = '';
$success = '';
$step = $_GET['step'] ?? 1;

// 检查是否已安装
if (file_exists('config/installed.lock')) {
    die('系统已安装，如需重新安装请削除 config/installed.lock 文件');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step == 1) {
        // データベース設定
        $dbHost = $_POST['db_host'] ?? 'localhost';
        $dbName = $_POST['db_name'] ?? '';
        $dbUser = $_POST['db_user'] ?? '';
        $dbPass = $_POST['db_pass'] ?? '';
        
        if ($dbName && $dbUser) {
            // 测试数据库连接
            $connection = mysqli_connect($dbHost, $dbUser, $dbPass);
            
            if (!$connection) {
                $error = '数据库连接失败: ' . mysqli_connect_error();
            } else {
                // 设置字符集
                mysqli_set_charset($connection, 'utf8mb4');
                
                // 创建数据库
                $createDbQuery = "CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
                if (!mysqli_query($connection, $createDbQuery)) {
                    $error = '创建数据库失败: ' . mysqli_error($connection);
                } else {
                    // 选择数据库
                    if (!mysqli_select_db($connection, $dbName)) {
                        $error = '选择数据库失败: ' . mysqli_error($connection);
                    } else {
                        // 创建表
                        $sql = file_get_contents('database_schema.sql');
                        
                        // 分割SQL语句并逐个执行
                        $queries = explode(';', $sql);
                        foreach ($queries as $query) {
                            $query = trim($query);
                            if (!empty($query)) {
                                if (!mysqli_query($connection, $query)) {
                                    $error = '创建表失败: ' . mysqli_error($connection);
                                    break;
                                }
                            }
                        }
                        
                        if (empty($error)) {
                            // 更新配置文件
                            $configContent = file_get_contents('config/database.php');
                            $configContent = str_replace('your_username', $dbUser, $configContent);
                            $configContent = str_replace('your_password', $dbPass, $configContent);
                            $configContent = str_replace('netdisk_db', $dbName, $configContent);
                            $configContent = str_replace('localhost', $dbHost, $configContent);
                            file_put_contents('config/database.php', $configContent);
                            
                            $success = 'データベース設定成功！';
                            $step = 2;
                        }
                    }
                }
                
                mysqli_close($connection);
            }
        } else {
            $error = '请填写所有必要信息';
        }
    } elseif ($step == 2) {
        // 管理者アカウントを作成
        $username = $_POST['admin_username'] ?? '';
        $password = $_POST['admin_password'] ?? '';
        
        if ($username && $password && strlen($password) >= 6) {
            require_once 'config/database.php';
            
            // 检查ユーザー名是否已存在
            $existing = fetchOne("SELECT id FROM users WHERE username = ?", [$username]);
            
            if ($existing) {
                $error = 'ユーザー名已存在';
            } else {
                // 管理者アカウントを作成
                $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                $result = executeQuery(
                    "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                    [$username, $passwordHash]
                );
                
                if ($result > 0) {
                    // 创建安装锁定文件
                    file_put_contents('config/installed.lock', date('Y-m-d H:i:s'));
                    
                    $success = 'インストール完了！请削除 install.php 文件并使用開始系统。';
                    $step = 3;
                } else {
                    $error = '管理者アカウントを作成失败';
                }
            }
        } else {
            $error = '请填写ユーザー名和パスワード（パスワード至少6位）';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>システムインストール - PHPクラウドストレージ</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <div class="card" style="max-width: 600px; margin: 50px auto;">
            <div style="text-align: center; margin-bottom: 30px;">
                <h1 class="logo">📁 PHPクラウドストレージシステムインストール</h1>
                <p style="color: #666; margin-top: 10px;">欢迎使用PHPクラウドストレージ系统</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            
            <?php if ($step == 1): ?>
                <h2>步骤 1: データベース設定</h2>
                <form method="POST" action="?step=1">
                    <div class="form-group">
                        <label for="db_host" class="form-label">データベースホスト</label>
                        <input type="text" id="db_host" name="db_host" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['db_host'] ?? 'localhost'); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_name" class="form-label">データベース名</label>
                        <input type="text" id="db_name" name="db_name" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['db_name'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_user" class="form-label">数据库ユーザー名</label>
                        <input type="text" id="db_user" name="db_user" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['db_user'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_pass" class="form-label">数据库パスワード</label>
                        <input type="password" id="db_pass" name="db_pass" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">次へ</button>
                    </div>
                </form>
                
            <?php elseif ($step == 2): ?>
                <h2>步骤 2: 管理者アカウントを作成</h2>
                <form method="POST" action="?step=2">
                    <div class="form-group">
                        <label for="admin_username" class="form-label">管理员ユーザー名</label>
                        <input type="text" id="admin_username" name="admin_username" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['admin_username'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="admin_password" class="form-label">管理员パスワード</label>
                        <input type="password" id="admin_password" name="admin_password" class="form-control" required>
                        <small style="color: #666;">パスワード长度至少6位</small>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">インストール完了</button>
                    </div>
                </form>
                
            <?php elseif ($step == 3): ?>
                <h2>🎉 インストール完了！</h2>
                <div style="text-align: center; padding: 20px;">
                    <p style="font-size: 18px; color: #28a745; margin-bottom: 20px;">
                        PHPクラウドストレージシステムインストール成功！
                    </p>
                    <p style="color: #666; margin-bottom: 20px;">
                        为了安全起见，请立即削除 <code>install.php</code> 文件。
                    </p>
                    <a href="login.php" class="btn btn-primary">使用開始</a>
                </div>
            <?php endif; ?>
            
            <?php if ($step < 3): ?>
                <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e9ecef;">
                    <h3>系统要求</h3>
                    <ul style="color: #666; font-size: 14px;">
                        <li>PHP 7.4 或更高版本</li>
                        <li>MySQL 5.7 或更高版本</li>
                        <li>mysqli 扩展</li>
                        <li>fileinfo 扩展</li>
                        <li>uploads/ 目录可写权限</li>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

