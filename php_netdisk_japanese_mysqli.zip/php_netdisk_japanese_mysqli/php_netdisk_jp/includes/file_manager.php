<?php
require_once 'config/database.php';

class FileManager {
    private $uploadDir = 'uploads/';
    
    public function __construct() {
        // 确保上传目录存在
        if (!is_dir($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
    }
    
    // 上传文件
    public function uploadFile($file, $userId) {
        // 检查文件是否有效
        if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return ['success' => false, 'message' => '无效的文件'];
        }
        
        // 检查文件大小
        $maxSize = 50 * 1024 * 1024; // 50MB
        if ($file['size'] > $maxSize) {
            return ['success' => false, 'message' => '文件大小超过限制'];
        }
        
        // 检查文件类型
        $allowedTypes = [
            'image/jpeg', 'image/png', 'image/gif', 'image/webp',
            'video/mp4', 'video/avi', 'video/mov', 'video/wmv',
            'audio/mp3', 'audio/wav', 'audio/ogg',
            'application/pdf', 'application/msword', 'application/vnd.ms-excel',
            'application/zip', 'application/x-rar-compressed',
            'text/plain', 'text/csv', 'text/html', 'text/css', 'application/javascript',
            'application/json', 'application/xml'
        ];
        
        $fileType = mime_content_type($file['tmp_name']);
        if (!in_array($fileType, $allowedTypes)) {
            return ['success' => false, 'message' => '不支持的文件类型'];
        }
        
        // 生成唯一文件名
        $originalName = $file['name'];
        $extension = pathinfo($originalName, PATHINFO_EXTENSION);
        $fileName = uniqid() . '_' . time() . '.' . $extension;
        $filePath = $this->uploadDir . $fileName;
        
        // 移动文件
        if (move_uploaded_file($file['tmp_name'], $filePath)) {
            // 保存文件信息到数据库
            $result = executeQuery(
                "INSERT INTO files (user_id, original_name, file_name, file_path, file_size, file_type) VALUES (?, ?, ?, ?, ?, ?)",
                [$userId, $originalName, $fileName, $filePath, $file['size'], $fileType]
            );
            
            if ($result > 0) {
                return ['success' => true, 'message' => '文件上传成功', 'file_id' => getLastInsertId()];
            } else {
                unlink($filePath); // 删除已上传的文件
                return ['success' => false, 'message' => '数据库保存失败'];
            }
        }
        
        return ['success' => false, 'message' => '文件上传失败'];
    }
    
    // 获取用户文件列表
    public function getUserFiles($userId, $search = '') {
        $query = "SELECT * FROM files WHERE user_id = ?";
        $params = [$userId];
        
        if (!empty($search)) {
            $query .= " AND original_name LIKE ?";
            $params[] = '%' . $search . '%';
        }
        
        $query .= " ORDER BY created_at DESC";
        
        return executeQuery($query, $params);
    }
    
    // 获取文件信息
    public function getFileInfo($fileId, $userId = null) {
        $query = "SELECT * FROM files WHERE id = ?";
        $params = [$fileId];
        
        if ($userId !== null) {
            $query .= " AND user_id = ?";
            $params[] = $userId;
        }
        
        $files = executeQuery($query, $params);
        return !empty($files) ? $files[0] : null;
    }
    
    // 删除文件
    public function deleteFile($fileId, $userId) {
        $file = $this->getFileInfo($fileId, $userId);
        if (!$file) {
            return ['success' => false, 'message' => '文件不存在或无权限'];
        }
        
        // 删除物理文件
        if (file_exists($file['file_path'])) {
            unlink($file['file_path']);
        }
        
        // 删除数据库记录
        $result = executeQuery(
            "DELETE FROM files WHERE id = ? AND user_id = ?",
            [$fileId, $userId]
        );
        
        if ($result > 0) {
            return ['success' => true, 'message' => '文件删除成功'];
        } else {
            return ['success' => false, 'message' => '文件删除失败'];
        }
    }
    
    // 重命名文件
    public function renameFile($fileId, $newName, $userId) {
        $file = $this->getFileInfo($fileId, $userId);
        if (!$file) {
            return ['success' => false, 'message' => '文件不存在或无权限'];
        }
        
        $result = executeQuery(
            "UPDATE files SET original_name = ? WHERE id = ? AND user_id = ?",
            [$newName, $fileId, $userId]
        );
        
        if ($result > 0) {
            return ['success' => true, 'message' => '文件重命名成功'];
        } else {
            return ['success' => false, 'message' => '文件重命名失败'];
        }
    }
    
    // 导入本地文件
    public function importLocalFile($filePath, $displayName, $userId) {
        // 检查文件是否存在
        if (!file_exists($filePath)) {
            return ['success' => false, 'message' => '文件不存在'];
        }
        
        // 安全检查：防止路径遍历攻击
        $realPath = realpath($filePath);
        if ($realPath === false || strpos($realPath, realpath($_SERVER['DOCUMENT_ROOT'])) !== 0) {
            return ['success' => false, 'message' => '无效的文件路径'];
        }
        
        // 获取文件信息
        $fileSize = filesize($filePath);
        $fileType = mime_content_type($filePath);
        $originalName = $displayName ?: basename($filePath);
        
        // 生成新的文件名和路径
        $extension = pathinfo($filePath, PATHINFO_EXTENSION);
        $fileName = uniqid() . '_' . time() . '.' . $extension;
        $newFilePath = $this->uploadDir . $fileName;
        
        // 复制文件到上传目录
        if (copy($filePath, $newFilePath)) {
            // 保存文件信息到数据库
            $result = executeQuery(
                "INSERT INTO files (user_id, original_name, file_name, file_path, file_size, file_type) VALUES (?, ?, ?, ?, ?, ?)",
                [$userId, $originalName, $fileName, $newFilePath, $fileSize, $fileType]
            );
            
            if ($result > 0) {
                return ['success' => true, 'message' => '文件导入成功', 'file_id' => getLastInsertId()];
            } else {
                unlink($newFilePath); // 删除已复制的文件
                return ['success' => false, 'message' => '数据库保存失败'];
            }
        }
        
        return ['success' => false, 'message' => '文件导入失败'];
    }
    
    // 获取用户存储统计
    public function getUserStats($userId) {
        $files = executeQuery(
            "SELECT COUNT(*) as file_count, SUM(file_size) as total_size FROM files WHERE user_id = ?",
            [$userId]
        );
        
        return !empty($files) ? $files[0] : ['file_count' => 0, 'total_size' => 0];
    }
}
?>

