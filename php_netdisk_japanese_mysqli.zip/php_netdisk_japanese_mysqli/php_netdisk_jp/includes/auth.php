<?php
require_once 'config/database.php';

class Auth {
    
    // 用户注册
    public function register($username, $password) {
        // 检查用户名是否已存在
        $existing = executeQuery(
            "SELECT id FROM users WHERE username = ?", 
            [$username]
        );
        
        if (!empty($existing)) {
            return ['success' => false, 'message' => '用户名已存在'];
        }
        
        // 创建新用户
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        $result = executeQuery(
            "INSERT INTO users (username, password_hash) VALUES (?, ?)",
            [$username, $passwordHash]
        );
        
        if ($result > 0) {
            return ['success' => true, 'message' => '注册成功'];
        } else {
            return ['success' => false, 'message' => '注册失败'];
        }
    }
    
    // 用户登录
    public function login($username, $password) {
        $users = executeQuery(
            "SELECT id, username, password_hash FROM users WHERE username = ?",
            [$username]
        );
        
        if (!empty($users)) {
            $user = $users[0];
            if (password_verify($password, $user['password_hash'])) {
                session_start();
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                return ['success' => true, 'message' => '登录成功'];
            }
        }
        
        return ['success' => false, 'message' => '用户名或密码错误'];
    }
    
    // 检查是否已登录
    public function isLoggedIn() {
        session_start();
        return isset($_SESSION['user_id']);
    }
    
    // 获取当前用户ID
    public function getCurrentUserId() {
        session_start();
        return $_SESSION['user_id'] ?? null;
    }
    
    // 获取当前用户名
    public function getCurrentUsername() {
        session_start();
        return $_SESSION['username'] ?? null;
    }
    
    // 用户退出登录
    public function logout() {
        session_start();
        session_destroy();
        return ['success' => true, 'message' => '退出成功'];
    }
    
    // 验证用户权限
    public function requireLogin() {
        if (!$this->isLoggedIn()) {
            header('Location: login.php');
            exit;
        }
    }
    
    // 获取用户信息
    public function getUserInfo($userId) {
        $users = executeQuery(
            "SELECT id, username, created_at FROM users WHERE id = ?",
            [$userId]
        );
        
        return !empty($users) ? $users[0] : null;
    }
}
?>

