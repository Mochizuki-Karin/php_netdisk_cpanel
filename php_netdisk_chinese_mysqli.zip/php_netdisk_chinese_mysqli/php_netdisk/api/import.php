<?php
header('Content-Type: application/json');
require_once '../includes/auth.php';
require_once '../includes/file_manager.php';

$auth = new Auth();
$fileManager = new FileManager();

// 检查用户是否已登录
if (!$auth->isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

$userId = $auth->getCurrentUserId();

// 获取POST数据
$input = json_decode(file_get_contents('php://input'), true);
$filePath = $input['file_path'] ?? '';
$displayName = $input['display_name'] ?? '';

if (empty($filePath)) {
    echo json_encode(['success' => false, 'message' => '文件路径不能为空']);
    exit;
}

// 导入本地文件
$result = $fileManager->importLocalFile($filePath, $displayName, $userId);

echo json_encode($result);
?>

