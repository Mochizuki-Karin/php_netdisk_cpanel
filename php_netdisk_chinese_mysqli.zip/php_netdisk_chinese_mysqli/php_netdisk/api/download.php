<?php
require_once '../includes/auth.php';
require_once '../includes/file_manager.php';

$auth = new Auth();
$fileManager = new FileManager();

// 检查用户是否已登录
if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit;
}

$userId = $auth->getCurrentUserId();
$fileId = $_GET['id'] ?? '';

if (empty($fileId)) {
    die('文件ID不能为空');
}

// 获取文件信息
$file = $fileManager->getFileInfo($fileId, $userId);

if (!$file) {
    die('文件不存在或无权限访问');
}

// 检查文件是否存在
if (!file_exists($file['file_path'])) {
    die('文件不存在');
}

// 设置下载头
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $file['original_name'] . '"');
header('Content-Length: ' . $file['file_size']);
header('Cache-Control: must-revalidate');
header('Pragma: public');

// 输出文件内容
readfile($file['file_path']);
exit;
?>

