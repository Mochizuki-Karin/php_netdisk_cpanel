<?php
header('Content-Type: application/json');
require_once '../includes/auth.php';
require_once '../includes/file_manager.php';

$auth = new Auth();
$fileManager = new FileManager();

// 检查用户是否已登录
if (!$auth->isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

$userId = $auth->getCurrentUserId();

// 获取POST数据
$input = json_decode(file_get_contents('php://input'), true);
$fileId = $input['file_id'] ?? '';

if (empty($fileId)) {
    echo json_encode(['success' => false, 'message' => '文件ID不能为空']);
    exit;
}

// 删除文件
$result = $fileManager->deleteFile($fileId, $userId);

echo json_encode($result);
?>

