<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_NAME', 'netdisk_db');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');

// 数据库连接函数
function connectDB() {
    $connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if (!$connection) {
        die('数据库连接失败: ' . mysqli_connect_error());
    }
    
    // 设置字符集
    mysqli_set_charset($connection, 'utf8mb4');
    
    return $connection;
}

// 关闭数据库连接
function closeDB($connection) {
    if ($connection) {
        mysqli_close($connection);
    }
}

// 执行查询并返回结果
function executeQuery($query, $params = []) {
    $connection = connectDB();
    
    // 如果有参数，使用预处理语句
    if (!empty($params)) {
        $stmt = mysqli_prepare($connection, $query);
        if (!$stmt) {
            closeDB($connection);
            return false;
        }
        
        // 绑定参数
        if (!empty($params)) {
            $types = '';
            foreach ($params as $param) {
                if (is_int($param)) {
                    $types .= 'i';
                } elseif (is_float($param)) {
                    $types .= 'd';
                } else {
                    $types .= 's';
                }
            }
            mysqli_stmt_bind_param($stmt, $types, ...$params);
        }
        
        $result = mysqli_stmt_execute($stmt);
        
        if (!$result) {
            mysqli_stmt_close($stmt);
            closeDB($connection);
            return false;
        }
        
        $queryResult = mysqli_stmt_get_result($stmt);
        mysqli_stmt_close($stmt);
    } else {
        $queryResult = mysqli_query($connection, $query);
    }
    
    if (!$queryResult) {
        closeDB($connection);
        return false;
    }
    
    // 如果是SELECT查询，返回结果数组
    if (stripos($query, 'SELECT') === 0) {
        $data = [];
        while ($row = mysqli_fetch_assoc($queryResult)) {
            $data[] = $row;
        }
        if (is_object($queryResult)) {
            mysqli_free_result($queryResult);
        }
        closeDB($connection);
        return $data;
    }
    
    // 对于INSERT/UPDATE/DELETE，返回影响的行数
    $affectedRows = mysqli_affected_rows($connection);
    closeDB($connection);
    return $affectedRows;
}

// 获取最后插入的ID
function getLastInsertId() {
    $connection = connectDB();
    $id = mysqli_insert_id($connection);
    closeDB($connection);
    return $id;
}

// 转义字符串防止SQL注入
function escapeString($string) {
    $connection = connectDB();
    $escaped = mysqli_real_escape_string($connection, $string);
    closeDB($connection);
    return $escaped;
}

// 获取单行结果
function fetchOne($query, $params = []) {
    $results = executeQuery($query, $params);
    return !empty($results) ? $results[0] : null;
}

// 获取所有结果
function fetchAll($query, $params = []) {
    return executeQuery($query, $params);
}
?>

