<?php
require_once 'config/database.php';

class ShareManager {
    
    // 创建分享链接
    public function createShare($fileId, $userId, $expiresAt = null) {
        // 检查文件是否存在且属于用户
        $files = executeQuery(
            "SELECT * FROM files WHERE id = ? AND user_id = ?",
            [$fileId, $userId]
        );
        
        if (empty($files)) {
            return ['success' => false, 'message' => '文件不存在或无权限'];
        }
        
        // 检查是否已有分享链接
        $existingShares = executeQuery(
            "SELECT * FROM shares WHERE file_id = ? AND user_id = ?",
            [$fileId, $userId]
        );
        
        if (!empty($existingShares)) {
            $share = $existingShares[0];
            return [
                'success' => true, 
                'message' => '分享链接已存在',
                'share_token' => $share['share_token'],
                'share_url' => $this->getShareUrl($share['share_token'])
            ];
        }
        
        // 生成唯一的分享令牌
        $shareToken = $this->generateShareToken();
        
        // 创建分享记录
        $result = executeQuery(
            "INSERT INTO shares (file_id, user_id, share_token, expires_at) VALUES (?, ?, ?, ?)",
            [$fileId, $userId, $shareToken, $expiresAt]
        );
        
        if ($result > 0) {
            return [
                'success' => true,
                'message' => '分享链接创建成功',
                'share_token' => $shareToken,
                'share_url' => $this->getShareUrl($shareToken)
            ];
        } else {
            return ['success' => false, 'message' => '分享链接创建失败'];
        }
    }
    
    // 删除分享链接
    public function deleteShare($shareId, $userId) {
        $result = executeQuery(
            "DELETE FROM shares WHERE id = ? AND user_id = ?",
            [$shareId, $userId]
        );
        
        if ($result > 0) {
            return ['success' => true, 'message' => '分享链接删除成功'];
        } else {
            return ['success' => false, 'message' => '分享链接删除失败或不存在'];
        }
    }
    
    // 通过令牌获取分享信息
    public function getShareByToken($shareToken) {
        $shares = executeQuery(
            "SELECT s.*, f.original_name, f.file_name, f.file_path, f.file_size, f.file_type, u.username 
             FROM shares s 
             JOIN files f ON s.file_id = f.id 
             JOIN users u ON s.user_id = u.id 
             WHERE s.share_token = ?",
            [$shareToken]
        );
        
        if (empty($shares)) {
            return null;
        }
        
        $share = $shares[0];
        
        // 检查是否过期
        if ($share['expires_at'] && strtotime($share['expires_at']) < time()) {
            return null;
        }
        
        return $share;
    }
    
    // 获取用户的分享列表
    public function getUserShares($userId) {
        return executeQuery(
            "SELECT s.*, f.original_name, f.file_size 
             FROM shares s 
             JOIN files f ON s.file_id = f.id 
             WHERE s.user_id = ? 
             ORDER BY s.created_at DESC",
            [$userId]
        );
    }
    
    // 增加访问次数
    public function incrementAccessCount($shareToken) {
        $result = executeQuery(
            "UPDATE shares SET access_count = access_count + 1 WHERE share_token = ?",
            [$shareToken]
        );
        
        return $result > 0;
    }
    
    // 生成分享令牌
    private function generateShareToken() {
        return bin2hex(random_bytes(16));
    }
    
    // 获取分享URL
    private function getShareUrl($shareToken) {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $scriptName = dirname($_SERVER['SCRIPT_NAME']);
        
        return $protocol . '://' . $host . $scriptName . '/share.php?token=' . $shareToken;
    }
    
    // 检查文件是否可以预览
    public function canPreview($fileType) {
        $previewableTypes = [
            'image/jpeg', 'image/png', 'image/gif', 'image/webp',
            'video/mp4', 'video/webm',
            'audio/mp3', 'audio/wav', 'audio/ogg',
            'text/plain', 'text/html', 'text/css', 'application/javascript',
            'application/json', 'application/xml'
        ];
        
        return in_array($fileType, $previewableTypes);
    }
    
    // 获取文件图标
    public function getFileIcon($fileType) {
        $iconMap = [
            'image/jpeg' => '🖼️', 'image/png' => '🖼️', 'image/gif' => '🖼️', 'image/webp' => '🖼️',
            'video/mp4' => '🎥', 'video/avi' => '🎥', 'video/mov' => '🎥', 'video/wmv' => '🎥',
            'audio/mp3' => '🎵', 'audio/wav' => '🎵', 'audio/ogg' => '🎵',
            'application/pdf' => '📄', 'application/msword' => '📝', 'application/vnd.ms-excel' => '📊',
            'application/zip' => '📦', 'application/x-rar-compressed' => '📦',
            'text/plain' => '📄', 'text/csv' => '📊', 'text/html' => '🌐',
            'text/css' => '🎨', 'application/javascript' => '⚙️',
            'application/json' => '📋', 'application/xml' => '📋'
        ];
        
        return $iconMap[$fileType] ?? '📄';
    }
    
    // 格式化文件大小
    public function formatFileSize($bytes) {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        
        $bytes /= (1 << (10 * $pow));
        
        return round($bytes, 2) . ' ' . $units[$pow];
    }
}
?>

