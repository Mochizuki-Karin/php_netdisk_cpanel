// 主要JavaScript功能
class NetDisk {
    constructor() {
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.initUploadArea();
        this.loadFiles();
    }
    
    // 绑定事件
    bindEvents() {
        // 文件上传
        const uploadInput = document.getElementById('fileInput');
        if (uploadInput) {
            uploadInput.addEventListener('change', (e) => this.handleFileSelect(e));
        }
        
        // 模态框关闭
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal') || e.target.classList.contains('modal-close')) {
                this.closeModal();
            }
        });
        
        // ESC键关闭模态框
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeModal();
            }
        });
        
        // 搜索功能
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => this.searchFiles(e.target.value));
        }
    }
    
    // 初始化上传区域
    initUploadArea() {
        const uploadArea = document.getElementById('uploadArea');
        if (!uploadArea) return;
        
        // 拖拽上传
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });
        
        uploadArea.addEventListener('dragleave', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            const files = e.dataTransfer.files;
            this.uploadFiles(files);
        });
        
        // 点击上传
        uploadArea.addEventListener('click', () => {
            document.getElementById('fileInput').click();
        });
    }
    
    // 处理文件选择
    handleFileSelect(event) {
        const files = event.target.files;
        this.uploadFiles(files);
    }
    
    // 上传文件
    async uploadFiles(files) {
        for (let file of files) {
            await this.uploadSingleFile(file);
        }
        this.loadFiles(); // 重新加载文件列表
    }
    
    // 上传单个文件
    async uploadSingleFile(file) {
        const formData = new FormData();
        formData.append('file', file);
        
        try {
            const response = await fetch('api/upload.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.showAlert('文件上传成功', 'success');
            } else {
                this.showAlert(result.message || '上传失败', 'error');
            }
        } catch (error) {
            this.showAlert('上传过程中发生错误', 'error');
            console.error('Upload error:', error);
        }
    }
    
    // 加载文件列表
    async loadFiles() {
        try {
            const response = await fetch('api/files.php');
            const result = await response.json();
            
            if (result.success) {
                this.renderFileList(result.files);
            } else {
                this.showAlert(result.message || '加载文件列表失败', 'error');
            }
        } catch (error) {
            this.showAlert('加载文件列表时发生错误', 'error');
            console.error('Load files error:', error);
        }
    }
    
    // 渲染文件列表
    renderFileList(files) {
        const fileList = document.getElementById('fileList');
        if (!fileList) return;
        
        if (files.length === 0) {
            fileList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-state-icon">📁</div>
                    <div class="empty-state-text">暂无文件</div>
                    <div class="empty-state-hint">上传您的第一个文件开始使用</div>
                </div>
            `;
            return;
        }
        
        fileList.innerHTML = files.map(file => `
            <div class="file-item" data-file-id="${file.id}">
                <div class="file-icon ${this.getFileIconClass(file.mime_type)}">
                    ${this.getFileIcon(file.mime_type)}
                </div>
                <div class="file-info">
                    <div class="file-name">${this.escapeHtml(file.filename)}</div>
                    <div class="file-meta">
                        ${this.formatFileSize(file.filesize)} • ${this.formatDate(file.created_at)}
                        ${file.share_token ? ' • 已分享' : ''}
                    </div>
                </div>
                <div class="file-actions">
                    <button class="btn btn-secondary" onclick="netdisk.downloadFile(${file.id})">
                        📥 下载
                    </button>
                    <button class="btn btn-secondary" onclick="netdisk.showShareModal(${file.id}, '${file.filename}', '${file.share_token || ''}')">
                        🔗 分享
                    </button>
                    <button class="btn btn-secondary" onclick="netdisk.showRenameModal(${file.id}, '${this.escapeHtml(file.filename)}')">
                        ✏️ 重命名
                    </button>
                    <button class="btn btn-danger" onclick="netdisk.deleteFile(${file.id})">
                        🗑️ 删除
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    // 获取文件图标类
    getFileIconClass(mimeType) {
        if (mimeType.startsWith('image/')) return 'image';
        if (mimeType.startsWith('video/')) return 'video';
        if (mimeType.includes('zip') || mimeType.includes('rar') || mimeType.includes('tar')) return 'archive';
        if (mimeType.includes('text') || mimeType.includes('document')) return 'document';
        return 'other';
    }
    
    // 获取文件图标
    getFileIcon(mimeType) {
        if (mimeType.startsWith('image/')) return '🖼️';
        if (mimeType.startsWith('video/')) return '🎥';
        if (mimeType.startsWith('audio/')) return '🎵';
        if (mimeType.includes('zip') || mimeType.includes('rar') || mimeType.includes('tar')) return '📦';
        if (mimeType.includes('pdf')) return '📄';
        if (mimeType.includes('text')) return '📝';
        if (mimeType.includes('document') || mimeType.includes('word')) return '📄';
        if (mimeType.includes('spreadsheet') || mimeType.includes('excel')) return '📊';
        return '📄';
    }
    
    // 下载文件
    downloadFile(fileId) {
        window.open(`api/download.php?id=${fileId}`, '_blank');
    }
    
    // 删除文件
    async deleteFile(fileId) {
        if (!confirm('确定要删除这个文件吗？')) return;
        
        try {
            const response = await fetch('api/delete.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ file_id: fileId })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.showAlert('文件删除成功', 'success');
                this.loadFiles();
            } else {
                this.showAlert(result.message || '删除失败', 'error');
            }
        } catch (error) {
            this.showAlert('删除过程中发生错误', 'error');
            console.error('Delete error:', error);
        }
    }
    
    // 显示分享模态框
    showShareModal(fileId, filename, shareToken) {
        const modal = document.getElementById('shareModal');
        const modalTitle = modal.querySelector('.modal-title');
        const shareContent = modal.querySelector('#shareContent');
        
        modalTitle.textContent = `分享文件: ${filename}`;
        
        if (shareToken) {
            const shareUrl = `${window.location.origin}${window.location.pathname.replace(/[^/]*$/, '')}share.php?token=${shareToken}`;
            shareContent.innerHTML = `
                <div class="form-group">
                    <label class="form-label">分享链接</label>
                    <div class="share-link">${shareUrl}</div>
                    <button class="btn btn-secondary" onclick="netdisk.copyToClipboard('${shareUrl}')">
                        📋 复制链接
                    </button>
                </div>
                <div class="form-group">
                    <button class="btn btn-danger" onclick="netdisk.deleteShare(${fileId})">
                        🗑️ 删除分享
                    </button>
                </div>
            `;
        } else {
            shareContent.innerHTML = `
                <div class="form-group">
                    <p>该文件尚未分享</p>
                    <button class="btn btn-primary" onclick="netdisk.createShare(${fileId})">
                        🔗 创建分享链接
                    </button>
                </div>
            `;
        }
        
        this.showModal('shareModal');
    }
    
    // 创建分享链接
    async createShare(fileId) {
        try {
            const response = await fetch('api/share.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ file_id: fileId, action: 'create' })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.showAlert('分享链接创建成功', 'success');
                this.closeModal();
                this.loadFiles();
            } else {
                this.showAlert(result.message || '创建分享链接失败', 'error');
            }
        } catch (error) {
            this.showAlert('创建分享链接时发生错误', 'error');
            console.error('Create share error:', error);
        }
    }
    
    // 删除分享链接
    async deleteShare(fileId) {
        if (!confirm('确定要删除分享链接吗？')) return;
        
        try {
            const response = await fetch('api/share.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ file_id: fileId, action: 'delete' })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.showAlert('分享链接已删除', 'success');
                this.closeModal();
                this.loadFiles();
            } else {
                this.showAlert(result.message || '删除分享链接失败', 'error');
            }
        } catch (error) {
            this.showAlert('删除分享链接时发生错误', 'error');
            console.error('Delete share error:', error);
        }
    }
    
    // 显示重命名模态框
    showRenameModal(fileId, currentName) {
        const modal = document.getElementById('renameModal');
        const input = modal.querySelector('#newFileName');
        
        input.value = currentName;
        input.dataset.fileId = fileId;
        
        this.showModal('renameModal');
        input.focus();
        input.select();
    }
    
    // 重命名文件
    async renameFile() {
        const input = document.getElementById('newFileName');
        const fileId = input.dataset.fileId;
        const newName = input.value.trim();
        
        if (!newName) {
            this.showAlert('文件名不能为空', 'error');
            return;
        }
        
        try {
            const response = await fetch('api/rename.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ file_id: fileId, new_name: newName })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.showAlert('文件重命名成功', 'success');
                this.closeModal();
                this.loadFiles();
            } else {
                this.showAlert(result.message || '重命名失败', 'error');
            }
        } catch (error) {
            this.showAlert('重命名过程中发生错误', 'error');
            console.error('Rename error:', error);
        }
    }
    
    // 复制到剪贴板
    async copyToClipboard(text) {
        try {
            await navigator.clipboard.writeText(text);
            this.showAlert('链接已复制到剪贴板', 'success');
        } catch (error) {
            // 降级方案
            const textArea = document.createElement('textarea');
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            this.showAlert('链接已复制到剪贴板', 'success');
        }
    }
    
    // 搜索文件
    searchFiles(query) {
        const fileItems = document.querySelectorAll('.file-item');
        
        fileItems.forEach(item => {
            const fileName = item.querySelector('.file-name').textContent.toLowerCase();
            const isVisible = fileName.includes(query.toLowerCase());
            item.style.display = isVisible ? 'flex' : 'none';
        });
    }
    
    // 显示模态框
    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    }
    
    // 关闭模态框
    closeModal() {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            modal.classList.remove('show');
        });
        document.body.style.overflow = '';
    }
    
    // 显示提示消息
    showAlert(message, type = 'info') {
        const alertContainer = document.getElementById('alertContainer') || this.createAlertContainer();
        
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.textContent = message;
        
        alertContainer.appendChild(alert);
        
        // 自动移除
        setTimeout(() => {
            if (alert.parentNode) {
                alert.parentNode.removeChild(alert);
            }
        }, 5000);
    }
    
    // 创建提示容器
    createAlertContainer() {
        const container = document.createElement('div');
        container.id = 'alertContainer';
        container.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            max-width: 400px;
        `;
        document.body.appendChild(container);
        return container;
    }
    
    // 格式化文件大小
    formatFileSize(bytes) {
        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        let size = bytes;
        let unitIndex = 0;
        
        while (size >= 1024 && unitIndex < units.length - 1) {
            size /= 1024;
            unitIndex++;
        }
        
        return `${size.toFixed(2)} ${units[unitIndex]}`;
    }
    
    // 格式化日期
    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('zh-CN') + ' ' + date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
    }
    
    // HTML转义
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// 初始化
let netdisk;
document.addEventListener('DOMContentLoaded', () => {
    netdisk = new NetDisk();
});

// 全局函数（用于内联事件处理）
window.netdisk = {
    downloadFile: (id) => netdisk.downloadFile(id),
    deleteFile: (id) => netdisk.deleteFile(id),
    showShareModal: (id, name, token) => netdisk.showShareModal(id, name, token),
    showRenameModal: (id, name) => netdisk.showRenameModal(id, name),
    createShare: (id) => netdisk.createShare(id),
    deleteShare: (id) => netdisk.deleteShare(id),
    renameFile: () => netdisk.renameFile(),
    copyToClipboard: (text) => netdisk.copyToClipboard(text)
};

