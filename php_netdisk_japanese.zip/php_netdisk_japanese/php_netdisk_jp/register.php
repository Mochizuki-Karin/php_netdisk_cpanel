<?php
require_once 'includes/auth.php';

$auth = new Auth();
$error = '';
$success = '';

// 处理新規登録请求
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    
    if ($username && $password && $confirmPassword) {
        if ($password === $confirmPassword) {
            if (strlen($password) >= 6) {
                $result = $auth->register($username, $password);
                if ($result['success']) {
                    $success = $result['message'] . ' ログインしてください。';
                } else {
                    $error = 'ユーザー名が既に存在します';
                }
            } else {
                $error = 'パスワードは6文字以上で入力してください';
            }
        } else {
            $error = '入力したパスワードが一致しません';
        }
    } else {
        $error = 'すべての項目を入力してください';
    }
}

// 如果已ログイン，重定向到主页
if ($auth->isLoggedIn()) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>新規登録 - PHPクラウドストレージ</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <div class="card" style="max-width: 400px; margin: 50px auto;">
            <div style="text-align: center; margin-bottom: 30px;">
                <h1 class="logo">📁 PHPクラウドストレージ</h1>
                <p style="color: #666; margin-top: 10px;">アカウントを作成</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="username" class="form-label">ユーザー名</label>
                    <input type="text" id="username" name="username" class="form-control" 
                           value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" 
                           required autofocus>
                    <small style="color: #666; font-size: 12px;">ユーザー名将用于ログイン</small>
                </div>
                
                <div class="form-group">
                    <label for="password" class="form-label">パスワード</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                    <small style="color: #666; font-size: 12px;">パスワード长度至少6位</small>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password" class="form-label">確認パスワード</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        📝 新規登録账户
                    </button>
                </div>
            </form>
            
            <div style="text-align: center; margin-top: 20px; padding-top: 20px; border-top: 1px solid #e9ecef;">
                <p style="color: #666; margin-bottom: 10px;">アカウントをお持ちの方</p>
                <a href="login.php" class="btn btn-secondary">🔐 立即ログイン</a>
            </div>
        </div>
    </div>
    
    <script>
        // 表单验证
        document.querySelector('form').addEventListener('submit', function(e) {
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (!username || !password || !confirmPassword) {
                e.preventDefault();
                alert('请填写所有字段');
                return;
            }
            
            if (password.length < 6) {
                e.preventDefault();
                alert('パスワード长度至少6位');
                return;
            }
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('两次输入的パスワード不一致');
                return;
            }
        });
        
        // 实时パスワード確認验证
        document.getElementById('confirm_password').addEventListener('input', function() {
            const password = document.getElementById('password').value;
            const confirmPassword = this.value;
            
            if (confirmPassword && password !== confirmPassword) {
                this.style.borderColor = '#dc3545';
            } else {
                this.style.borderColor = '#e9ecef';
            }
        });
    </script>
</body>
</html>

