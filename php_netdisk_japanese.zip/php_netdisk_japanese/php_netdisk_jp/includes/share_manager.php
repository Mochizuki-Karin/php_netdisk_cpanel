<?php
require_once 'config/database.php';

class ShareManager {
    private $db;
    
    public function __construct() {
        $this->db = new Database();
    }
    
    // 创建分享链接
    public function createShare($userId, $fileId, $expiresAt = null) {
        // 检查文件是否属于当前用户
        $file = $this->db->fetchOne(
            "SELECT * FROM files WHERE id = ? AND user_id = ?",
            [$fileId, $userId]
        );
        
        if (!$file) {
            return ['success' => false, 'message' => '文件不存在或无权限'];
        }
        
        // 检查是否已经有分享链接
        $existingShare = $this->db->fetchOne(
            "SELECT * FROM shares WHERE file_id = ?",
            [$fileId]
        );
        
        if ($existingShare) {
            return [
                'success' => true, 
                'message' => '分享链接已存在',
                'share_token' => $existingShare['share_token'],
                'share_url' => $this->getShareUrl($existingShare['share_token'])
            ];
        }
        
        // 生成唯一的分享令牌
        $shareToken = $this->generateShareToken();
        
        // 保存分享记录
        $this->db->query(
            "INSERT INTO shares (file_id, share_token, expires_at) VALUES (?, ?, ?)",
            [$fileId, $shareToken, $expiresAt]
        );
        
        return [
            'success' => true,
            'message' => '分享链接创建成功',
            'share_token' => $shareToken,
            'share_url' => $this->getShareUrl($shareToken)
        ];
    }
    
    // 删除分享链接
    public function deleteShare($userId, $fileId) {
        // 检查文件是否属于当前用户
        $file = $this->db->fetchOne(
            "SELECT * FROM files WHERE id = ? AND user_id = ?",
            [$fileId, $userId]
        );
        
        if (!$file) {
            return ['success' => false, 'message' => '文件不存在或无权限'];
        }
        
        $result = $this->db->query(
            "DELETE FROM shares WHERE file_id = ?",
            [$fileId]
        );
        
        if ($result->rowCount() > 0) {
            return ['success' => true, 'message' => '分享链接已删除'];
        }
        
        return ['success' => false, 'message' => '分享链接不存在'];
    }
    
    // 通过分享令牌获取文件信息
    public function getFileByShareToken($shareToken) {
        $share = $this->db->fetchOne(
            "SELECT s.*, f.* FROM shares s 
             JOIN files f ON s.file_id = f.id 
             WHERE s.share_token = ?",
            [$shareToken]
        );
        
        if (!$share) {
            return null;
        }
        
        // 检查是否过期
        if ($share['expires_at'] && strtotime($share['expires_at']) < time()) {
            return null;
        }
        
        return $share;
    }
    
    // 获取用户的所有分享
    public function getUserShares($userId) {
        return $this->db->fetchAll(
            "SELECT s.*, f.filename, f.filesize, f.mime_type 
             FROM shares s 
             JOIN files f ON s.file_id = f.id 
             WHERE f.user_id = ? 
             ORDER BY s.created_at DESC",
            [$userId]
        );
    }
    
    // 更新分享过期时间
    public function updateShareExpiry($userId, $fileId, $expiresAt) {
        // 检查文件是否属于当前用户
        $file = $this->db->fetchOne(
            "SELECT * FROM files WHERE id = ? AND user_id = ?",
            [$fileId, $userId]
        );
        
        if (!$file) {
            return ['success' => false, 'message' => '文件不存在或无权限'];
        }
        
        $result = $this->db->query(
            "UPDATE shares SET expires_at = ? WHERE file_id = ?",
            [$expiresAt, $fileId]
        );
        
        if ($result->rowCount() > 0) {
            return ['success' => true, 'message' => '分享设置已更新'];
        }
        
        return ['success' => false, 'message' => '分享链接不存在'];
    }
    
    // 生成分享令牌
    private function generateShareToken() {
        return bin2hex(random_bytes(16));
    }
    
    // 生成分享URL
    private function getShareUrl($shareToken) {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $basePath = dirname($_SERVER['SCRIPT_NAME']);
        
        return $protocol . '://' . $host . $basePath . '/share.php?token=' . $shareToken;
    }
    
    // 检查分享是否有效
    public function isShareValid($shareToken) {
        $share = $this->db->fetchOne(
            "SELECT expires_at FROM shares WHERE share_token = ?",
            [$shareToken]
        );
        
        if (!$share) {
            return false;
        }
        
        // 检查是否过期
        if ($share['expires_at'] && strtotime($share['expires_at']) < time()) {
            return false;
        }
        
        return true;
    }
    
    // 获取分享统计信息
    public function getShareStats($userId) {
        $stats = $this->db->fetchOne(
            "SELECT COUNT(*) as total_shares 
             FROM shares s 
             JOIN files f ON s.file_id = f.id 
             WHERE f.user_id = ?",
            [$userId]
        );
        
        return $stats['total_shares'] ?? 0;
    }
}
?>

