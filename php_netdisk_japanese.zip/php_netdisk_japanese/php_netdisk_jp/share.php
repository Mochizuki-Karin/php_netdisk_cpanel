<?php
require_once 'includes/share_manager.php';
require_once 'includes/file_manager.php';

$shareManager = new ShareManager();
$fileManager = new FileManager();

$shareToken = $_GET['token'] ?? '';
$error = '';
$file = null;

if ($shareToken) {
    $file = $shareManager->getFileByShareToken($shareToken);
    if (!$file) {
        $error = '共有链接无效或已过期';
    }
} else {
    $error = '缺少共有令牌';
}

// 处理ダウンロード请求
if ($file && isset($_GET['download'])) {
    $filePath = __DIR__ . '/uploads/' . $file['file_path'];
    
    if (file_exists($filePath)) {
        header('Content-Type: ' . $file['mime_type']);
        header('Content-Disposition: attachment; filename="' . $file['filename'] . '"');
        header('Content-Length: ' . $file['filesize']);
        readfile($filePath);
        exit;
    } else {
        $error = '文件不存在';
    }
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $file ? htmlspecialchars($file['filename']) : '文件共有'; ?> - PHPクラウドストレージ</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .preview-container {
            max-width: 800px;
            margin: 0 auto;
            text-align: center;
        }
        
        .file-preview {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 40px;
            margin: 20px 0;
        }
        
        .file-preview img {
            max-width: 100%;
            max-height: 500px;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        
        .file-preview video {
            max-width: 100%;
            max-height: 500px;
            border-radius: 8px;
        }
        
        .file-info-card {
            background: white;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="preview-container">
            <!-- 头部 -->
            <div style="text-align: center; margin: 40px 0;">
                <h1 class="logo">📁 PHPクラウドストレージ</h1>
                <p style="color: #666; margin-top: 10px;">文件共有</p>
            </div>
            
            <?php if ($error): ?>
                <div class="file-info-card">
                    <div style="text-align: center; color: #dc3545;">
                        <div style="font-size: 64px; margin-bottom: 20px;">❌</div>
                        <h2>访问失败</h2>
                        <p style="margin: 20px 0; color: #666;"><?php echo htmlspecialchars($error); ?></p>
                        <a href="login.php" class="btn btn-primary">返回ログイン</a>
                    </div>
                </div>
            <?php elseif ($file): ?>
                <!-- 文件信息 -->
                <div class="file-info-card">
                    <div style="display: flex; align-items: center; justify-content: center; margin-bottom: 20px;">
                        <div class="file-icon <?php echo $fileManager->getFileIconClass($file['mime_type']); ?>" style="font-size: 48px; margin-right: 20px;">
                            <?php echo $fileManager->getFileIcon($file['mime_type']); ?>
                        </div>
                        <div style="text-align: left;">
                            <h2 style="margin: 0; color: #333;"><?php echo htmlspecialchars($file['filename']); ?></h2>
                            <p style="margin: 5px 0 0 0; color: #666;">
                                <?php echo $fileManager->formatFileSize($file['filesize']); ?> • 
                                <?php echo date('Y-m-d H:i', strtotime($file['created_at'])); ?>
                            </p>
                        </div>
                    </div>
                    
                    <div style="margin: 30px 0;">
                        <a href="?token=<?php echo urlencode($shareToken); ?>&download=1" class="btn btn-primary" style="font-size: 18px; padding: 15px 30px;">
                            📥 ダウンロード文件
                        </a>
                    </div>
                </div>
                
                <!-- 文件预览 -->
                <?php if (strpos($file['mime_type'], 'image/') === 0): ?>
                    <div class="file-preview">
                        <h3 style="margin-bottom: 20px; color: #333;">🖼️ 图片预览</h3>
                        <img src="uploads/<?php echo htmlspecialchars($file['file_path']); ?>" 
                             alt="<?php echo htmlspecialchars($file['filename']); ?>">
                    </div>
                <?php elseif (strpos($file['mime_type'], 'video/') === 0): ?>
                    <div class="file-preview">
                        <h3 style="margin-bottom: 20px; color: #333;">🎥 视频预览</h3>
                        <video controls>
                            <source src="uploads/<?php echo htmlspecialchars($file['file_path']); ?>" 
                                    type="<?php echo htmlspecialchars($file['mime_type']); ?>">
                            您的浏览器不支持视频播放。
                        </video>
                    </div>
                <?php elseif (strpos($file['mime_type'], 'audio/') === 0): ?>
                    <div class="file-preview">
                        <h3 style="margin-bottom: 20px; color: #333;">🎵 音频预览</h3>
                        <audio controls style="width: 100%; max-width: 500px;">
                            <source src="uploads/<?php echo htmlspecialchars($file['file_path']); ?>" 
                                    type="<?php echo htmlspecialchars($file['mime_type']); ?>">
                            您的浏览器不支持音频播放。
                        </audio>
                    </div>
                <?php elseif (strpos($file['mime_type'], 'text/') === 0 && $file['filesize'] < 1024 * 1024): ?>
                    <div class="file-preview">
                        <h3 style="margin-bottom: 20px; color: #333;">📝 文本预览</h3>
                        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 20px; text-align: left; max-height: 400px; overflow-y: auto;">
                            <pre style="white-space: pre-wrap; font-family: 'Courier New', monospace; margin: 0;"><?php 
                                $filePath = __DIR__ . '/uploads/' . $file['file_path'];
                                if (file_exists($filePath)) {
                                    echo htmlspecialchars(file_get_contents($filePath));
                                } else {
                                    echo '文件内容无法读取';
                                }
                            ?></pre>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="file-preview">
                        <div style="color: #666;">
                            <div style="font-size: 48px; margin-bottom: 20px;">📄</div>
                            <p>此文件类型不支持在线预览</p>
                            <p>请ダウンロード文件查看内容</p>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- 共有信息 -->
                <div class="file-info-card">
                    <h3 style="margin-bottom: 20px; color: #333;">ℹ️ 共有信息</h3>
                    <div style="text-align: left; max-width: 400px; margin: 0 auto;">
                        <p><strong>共有时间：</strong><?php echo date('Y-m-d H:i:s', strtotime($file['created_at'])); ?></p>
                        <?php if ($file['expires_at']): ?>
                            <p><strong>过期时间：</strong><?php echo date('Y-m-d H:i:s', strtotime($file['expires_at'])); ?></p>
                        <?php else: ?>
                            <p><strong>过期时间：</strong>永不过期</p>
                        <?php endif; ?>
                        <p><strong>文件类型：</strong><?php echo htmlspecialchars($file['mime_type']); ?></p>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- 底部链接 -->
            <div style="text-align: center; margin: 40px 0; padding-top: 20px; border-top: 1px solid #e9ecef;">
                <p style="color: #666; margin-bottom: 15px;">想要创建自己的网盘？</p>
                <a href="register.php" class="btn btn-secondary">📝 新規登録账户</a>
                <a href="login.php" class="btn btn-secondary" style="margin-left: 10px;">🔐 立即ログイン</a>
            </div>
        </div>
    </div>
    
    <script>
        // 自动复制共有链接功能
        function copyShareLink() {
            const url = window.location.href.split('&download=')[0];
            navigator.clipboard.writeText(url).then(() => {
                alert('共有链接已复制到剪贴板');
            }).catch(() => {
                // 降级方案
                const textArea = document.createElement('textarea');
                textArea.value = url;
                document.body.appendChild(textArea);
                textArea.select();
                document.execCommand('copy');
                document.body.removeChild(textArea);
                alert('共有链接已复制到剪贴板');
            });
        }
        
        // 添加复制链接按钮
        <?php if ($file): ?>
        document.addEventListener('DOMContentLoaded', function() {
            const downloadBtn = document.querySelector('.btn-primary');
            if (downloadBtn) {
                const copyBtn = document.createElement('button');
                copyBtn.className = 'btn btn-secondary';
                copyBtn.style.marginLeft = '10px';
                copyBtn.innerHTML = '🔗 复制链接';
                copyBtn.onclick = copyShareLink;
                downloadBtn.parentNode.appendChild(copyBtn);
            }
        });
        <?php endif; ?>
    </script>
</body>
</html>

